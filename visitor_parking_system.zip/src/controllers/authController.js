const authService = require('../services/authService');
const sendEmail = require('../utils/email');
const AppError = require('../utils/AppError');

exports.login = async (req, res, next) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return next(new AppError('Please provide email and password', 400));
        }

        const { user, token } = await authService.login(email, password);

        // Send login notification email
        await sendEmail({
            email: user.email,
            subject: 'Login Notification',
            message: `Hello ${user.name},\n\nYou have successfully logged in to the Visitor Parking System at ${new Date().toLocaleString()}.`
        });

        // Send token in cookie for UI access
        res.cookie('jwt', token, {
            expires: new Date(Date.now() + 24 * 60 * 60 * 1000),
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production'
        });

        res.status(200).json({
            status: 'success',
            token,
            data: {
                user: {
                    id: user.id,
                    name: user.name,
                    email: user.email
                }
            }
        });
    } catch (error) {
        next(error);
    }
};

exports.logout = (req, res) => {
    res.cookie('jwt', 'loggedout', {
        expires: new Date(Date.now() + 10 * 1000),
        httpOnly: true
    });
    res.status(200).json({ status: 'success' });
};
