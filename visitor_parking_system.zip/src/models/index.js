const User = require('./user');
const Visitor = require('./visitor');

// Associations can be defined here if needed
// User.hasMany(Visitor, { foreignKey: 'createdBy' });
// Visitor.belongsTo(User, { foreignKey: 'createdBy' });

module.exports = {
    User,
    Visitor
};
