const jwt = require('jsonwebtoken');
const { User } = require('../models');
const AppError = require('../utils/AppError');

class AuthService {
    async login(email, password) {
        const user = await User.findOne({ where: { email } });

        if (!user || !(await user.validatePassword(password))) {
            throw new AppError('Invalid email or password', 401);
        }

        const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, {
            expiresIn: process.env.JWT_EXPIRES_IN
        });

        return { user, token };
    }
}

module.exports = new AuthService();
