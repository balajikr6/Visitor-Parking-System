const { Op } = require('sequelize');
const { Visitor } = require('../models');
const AppError = require('../utils/AppError');
const excel = require('exceljs');
const PDFDocument = require('pdfkit');

class VisitorService {
    async createVisitor(data) {
        return await Visitor.create(data);
    }

    async getAllVisitors(query) {
        const { page = 1, limit = 10, search, status, fromDate, toDate } = query;
        const offset = (page - 1) * limit;

        const whereClause = {};

        if (search) {
            whereClause[Op.or] = [
                { plate_number: { [Op.iLike]: `%${search}%` } },
                { visitor_name: { [Op.iLike]: `%${search}%` } },
                { mobile_number: { [Op.iLike]: `%${search}%` } }
            ];
        }

        if (status) {
            whereClause.status = status;
        }

        if (fromDate && toDate) {
            whereClause.visit_date = {
                [Op.between]: [fromDate, toDate]
            };
        }

        const { count, rows } = await Visitor.findAndCountAll({
            where: whereClause,
            limit,
            offset,
            order: [['createdAt', 'DESC']]
        });

        return {
            visitors: rows,
            total: count,
            totalPages: Math.ceil(count / limit),
            currentPage: parseInt(page)
        };
    }

    async getVisitorById(id) {
        const visitor = await Visitor.findByPk(id);
        if (!visitor) {
            throw new AppError('Visitor not found', 404);
        }
        return visitor;
    }

    async updateVisitor(id, data) {
        const visitor = await Visitor.findByPk(id);
        if (!visitor) {
            throw new AppError('Visitor not found', 404);
        }
        return await visitor.update(data);
    }

    async deleteVisitor(id) {
        const visitor = await Visitor.findByPk(id);
        if (!visitor) {
            throw new AppError('Visitor not found', 404);
        }
        await visitor.destroy();
    }

    async generateExcel(query) {
        const visitors = await Visitor.findAll({ where: query });
        const workbook = new excel.Workbook();
        const worksheet = workbook.addWorksheet('Visitors');

        worksheet.columns = [
            { header: 'ID', key: 'id', width: 10 },
            { header: 'Name', key: 'visitor_name', width: 20 },
            { header: 'Plate Number', key: 'plate_number', width: 15 },
            { header: 'Mobile', key: 'mobile_number', width: 15 },
            { header: 'Purpose', key: 'purpose', width: 20 },
            { header: 'Entry Time', key: 'entry_time', width: 15 },
            { header: 'Status', key: 'status', width: 10 }
        ];

        worksheet.addRows(visitors);
        return workbook;
    }
}

module.exports = new VisitorService();
