# Visitor Parking System

A robust Node.js application for managing visitor parking, complete with authentication, visitor tracking, and reporting.

## Features

- **Authentication**: secure login with JWT, bcrypt for password hashing, and rate limiting.
- **Visitor Management**: create, view, update, and delete visitor records.
- **Validation**: Ensures unique active entries per vehicle per day.
- **Reporting**: Export visitor data to Excel and PDF.
- **Security**: Helmet headers, sanitized inputs, and protected routes.

## Prerequisites

- Node.js (v14+)
- PostgreSQL

## Setup Instructions

1.  **Clone/Extract** the repository.
2.  **Install dependencies**:
    ```bash
    npm install
    # or if missing:
    # npm install express pg pg-hstore sequelize dotenv bcryptjs jsonwebtoken cors helmet joi winston morgan nodemailer exceljs pdfkit ejs express-rate-limit cookie-parser
    # npm install --save-dev nodemon sequelize-cli jest supertest
    ```
3.  **Environment Configuration**:
    - Rename `.env.example` to `.env`.
    - Update database credentials and email settings.

4.  **Database Setup**:
    - Create a PostgreSQL database named `visitor_parking_db` (or as configured in `.env`).
    - Run migrations:
      ```bash
      npx sequelize-cli db:migrate
      ```
    - Run seeders (creates Admin user):
      ```bash
      npx sequelize-cli db:seed:all
      ```

5.  **Run the Application**:
    ```bash
    npm run dev
    ```
    - Access the UI at `http://localhost:3000`

## API Endpoints

- `POST /api/auth/login` - Login
- `GET /api/visitors` - List visitors
- `POST /api/visitors` - Add visitor
- `GET /api/visitors/:id` - Get visitor details
- `PUT /api/visitors/:id` - Update visitor
- `DELETE /api/visitors/:id` - Soft delete visitor
- `GET /api/visitors/download/excel` - Download Excel report
- `GET /api/visitors/download/pdf` - Download PDF report

## Project Structure

This project follows the **MVC (Model-View-Controller)** pattern:
- `src/config`: Database and app configuration.
- `src/controllers`: Request handlers.
- `src/models`: Sequelize definitions.
- `src/routes`: API definitions.
- `src/services`: Business logic layer.
- `src/views`: EJS templates for the frontend.

## Default Credentials
- **Email**: admin@parking.com
- **Password**: admin123
